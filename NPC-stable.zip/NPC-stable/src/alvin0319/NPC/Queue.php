<?php
declare(strict_types=1);
namespace alvin0319\NPC;

final class Queue{

	public static $removeQueue = [];

	public static $editQueue = [];

	public static $itemQueue = [];

	public static $offItemQueue = [];
}