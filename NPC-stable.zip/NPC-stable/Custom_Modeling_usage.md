# Description
If you want to add your custom skin or modeling, you can do it.

Follow this step if you want to do.

1. Put skin/modeling png file to `your_server_folder/plugin_data/NPC/images` folder.
2. If you want to apply geometry file, also put .json file to `your_server_folder/plugin_data/NPC/images` folder.
3. And, Join the server and type `/npc create your_npc_name npc your_skinfile_name.png your_geometry_file.json`. The geometry option is optional.
4. You can apply your Modeling like this! ![](https://raw.githubusercontent.com/alvin0319/NPC/master/images/model.png)


And, to apply modeling, you need to have the gd extension installed in your php binary.