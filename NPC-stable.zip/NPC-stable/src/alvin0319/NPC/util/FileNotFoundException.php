<?php
declare(strict_types=1);
namespace alvin0319\NPC\util;

class FileNotFoundException extends \Exception{
}