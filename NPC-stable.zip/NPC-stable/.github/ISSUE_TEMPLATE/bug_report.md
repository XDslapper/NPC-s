---
name: Bug report
about: Create a report to help us
title: ''
labels: ''
assignees: ''

---

Issue Description
-----------------

<!-- What issue are you experiencing? -->

How do you reproduce it?
------------------------

<!-- Please write how to reproduce -->

* Step 1: ...

* Step 2: ...

Your System information
--------------------------

* OS: Ubuntu/Windows

* Your PocketMine-MP Version: <!-- Your pocketmine-mp version or commit link -->

* Plugin Version: <!-- Your npc plugin version or commit link -->
