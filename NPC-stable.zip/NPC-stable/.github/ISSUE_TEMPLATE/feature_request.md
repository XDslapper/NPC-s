---
name: Feature request
about: Suggest an idea for this project
title: ''
labels: ''
assignees: ''

---

Issue Description
-----------------

<!-- What issue are you experiencing? -->

What do you want to change?
---------------------------

<!-- Write that what do you want to change -->

* Function 1: ...

* Function 2: ...

Additional content
------------------
....
